package com.funtimevisuals;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FuntimeVisuals implements ModInitializer {
    public static final String MOD_ID = "funtimevisuals";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Funtime Visuals for 1.21!");
    }
}
