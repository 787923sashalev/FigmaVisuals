package com.funtimevisuals.mixin;

import com.funtimevisuals.FuntimeVisualsClient;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @Inject(method = "getBrightness", at = @At("HEAD"), cancellable = true)
    private void overrideBrightness(int lightLevel, CallbackInfoReturnable<Float> cir) {
        if (FuntimeVisualsClient.fullBrightEnabled) {
            cir.setReturnValue(1.0F); // Fullbright effect
        }
    }
}
