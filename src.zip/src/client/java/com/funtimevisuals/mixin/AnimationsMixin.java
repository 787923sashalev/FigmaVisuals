package com.funtimevisuals.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public class AnimationsMixin {
    // Custom hit and hand animations
    @Inject(method = "getSpeed", at = @At("RETURN"), cancellable = true)
    private void modifySpeed(CallbackInfoReturnable<Float> cir) {
        // Modify animation speed or FOV (Aspect Ratio) effects
    }
}
