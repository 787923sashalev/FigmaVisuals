package com.funtimevisuals.mixin;

import com.funtimevisuals.FuntimeVisualsClient;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class CrosshairMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (FuntimeVisualsClient.customCrosshairEnabled) {
            // Cancel default crosshair
            ci.cancel();
            
            // Custom crosshair rendering logic here
            int width = context.getScaledWindowWidth();
            int height = context.getScaledWindowHeight();
            context.fill(width / 2 - 5, height / 2 - 1, width / 2 + 6, height / 2 + 2, 0xFF00FF00); // Horizontal green line
            context.fill(width / 2 - 1, height / 2 - 5, width / 2 + 2, height / 2 + 6, 0xFF00FF00); // Vertical green line
        }
    }
}
