package com.funtimevisuals.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class VisualsGui extends Screen {
    public VisualsGui() {
        super(Text.literal("Funtime Visuals - ClickGUI"));
    }

    @Override
    protected void init() {
        super.init();
        // Here we would add buttons for:
        // - Animations
        // - Block Overlay
        // - Crosshair
        // - Full Bright
        // - Hit Color
        // - China Hat
        // - Aspect Ratio
        // - Custom Hand
        // - Hit Bubble
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer, Text.literal("Modules:"), 20, 50, 0x00FF00);
        
        int y = 70;
        String[] modules = {
            "Animations (Custom swing/hit)",
            "Block Overlay (Custom outline)",
            "Crosshair (Custom texture/render)",
            "Full Bright (Gamma override)",
            "Hit Color (Red damage tint)",
            "China Hat (Cosmetic top hat)",
            "Aspect Ratio (FOV/Screen stretch)",
            "Custom Hand (Position offset)",
            "Hit Bubble (Damage particles)"
        };

        for (String mod : modules) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("- " + mod + " [ENABLED]"), 20, y, 0xFFFFFF);
            y += 15;
        }

        super.render(context, mouseX, mouseY, delta);
    }
}
