package com.funtimevisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class FuntimeVisualsClient implements ClientModInitializer {
    private static KeyBinding guiKeyBinding;

    // Features toggles (simplified for MVP)
    public static boolean fullBrightEnabled = true;
    public static boolean customCrosshairEnabled = true;

    @Override
    public void onInitializeClient() {
        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.funtimevisuals.open_gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.funtimevisuals.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKeyBinding.wasPressed()) {
                client.setScreen(new com.funtimevisuals.gui.VisualsGui());
            }
        });
    }
}
